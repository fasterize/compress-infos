'use strict';

const fs = require('fs');
const GZIP_MAGIC = '1f8b';

const isGZFile = (file) => {
  const fd = fs.openSync(file, 'r');
  if (!fd) {
    return false;
  }

  let result = false;
  let buffer = Buffer.alloc(2);
  if (2 == fs.readSync(fd, buffer, 0, 2, 0)) {
    result = isGZBuffer(buffer);
  }

  fs.closeSync(fd);
  return result;
};

const isGZBuffer = (buffer) => {
  if (Buffer.isBuffer(buffer) && buffer.length >= 2) {
    return Buffer
      .alloc(2, buffer)
      .toString('hex')
      .toLowerCase() == GZIP_MAGIC;
  } 
  return false;
};

const getGZBufferUncompressedSize = (buffer) => {
  if (isGZBuffer(buffer)) {
    return (buffer[buffer.length - 1] << 24) +
      (buffer[buffer.length - 2] << 16) +
      (buffer[buffer.length - 3] << 8) +
      buffer[buffer.length - 4];
  }

  return -1;
};

const getGZFileUncompressedSize = (filename) => {
  if (isGZFile(filename)) {
    const fileSize = fs.statSync(filename).size;
    const fd = fs.openSync(filename, 'r');
    if (!fd) {
      return -1;
    }

    var buffer = Buffer.alloc(4);
    var result = -1;
    if (4 == fs.readSync(fd, buffer, 0, 4, fileSize - 4)) {
      result = (buffer[3] << 24) + (buffer[2] << 16) + (buffer[1] << 8) + buffer[0];
    }

    fs.closeSync(fd);
    return result;
  }

  return -1;
};

module.exports = {
  "isGZFile": isGZFile,
  "isGZBuffer": isGZBuffer,
  "getGZFileUncompressedSize": getGZFileUncompressedSize,
  "getGZBufferUncompressedSize": getGZBufferUncompressedSize
};
